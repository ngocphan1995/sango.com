<?php

die('mod_rewrite works');
