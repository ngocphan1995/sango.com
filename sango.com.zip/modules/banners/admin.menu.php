<?php

/**
 * @Project NUKEVIET 4.x
 * @Author VINADES.,JSC (contact@vinades.vn)
 * @Copyright (C) 2014 VINADES.,JSC. All rights reserved
 * @License GNU/GPL version 2 or any later version
 * @Createdate 07/30/2013 10:27
 */

if (! defined('NV_ADMIN')) {
    die('Stop!!!');
}

$submenu['client_list'] = $lang_module['client_list'];
$submenu['add_client'] = $lang_module['add_client'];
$submenu['plans_list'] = $lang_module['plans_list'];
$submenu['add_plan'] = $lang_module['add_plan'];
$submenu['banners_list'] = $lang_module['banners_list'];
$submenu['add_banner'] = $lang_module['add_banner'];
